<?php

/**
 *
 * Facebook view
 *
 * @version             3.0.0
 * @package             Gavern Framework
 * @copyright			Copyright (C) 2010 - 2012 GavickPro. All rights reserved.
 *               
 */
 
// No direct access.
defined('_JEXEC') or die;

?>
<!DOCTYPE html>
<html>
<head>
	<jdoc:include type="head" />	
</head>
<body>
	<jdoc:include type="message" />
	<jdoc:include type="component" />
</body>
</html>