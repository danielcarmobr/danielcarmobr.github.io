<div id="copyright-outer" class="clr">
<div id="copyright-inner">
<div id="copyright">Copyright &copy; <?php echo date("Y"); ?> <?php echo "$sitetitle"; ?>. All Right Reserved.</div>
<div id="designer">Design by <a href="http://www.joomlasaver.com" target="_blank" title="www.joomlasaver.com">JoomlaSaver</a></div>
</div>
</div>